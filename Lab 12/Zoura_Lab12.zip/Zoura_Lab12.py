#--------------------------------------------------------------------
# Name: Topographic roughness index script.
# Author: Rita Zoura (UCID: 30018933)
# Created: 2020/12/7
#
# Purpose of script: take a dem raster dataset and output the topographic elevation index. 
#
# Inputs: Input raster
#         
#
# Outputs: Output raster
#
#--------------------------------------------------------------------

# import arcpy and spatial analyst tools module from arcpy.
import arcpy
from arcpy.sa import *

# sets the neighbourhood window for focal Statistics tool to 3x3 window
neighbourhood = NbrRectangle(3,3,"CELL")

# gets the imput raster from the user from the arcGIS GUI
D1 = Raster(arcpy.GetParameterAsText(0))

# Squares the imput raster and temporarily saves it for futher use
D2 = Square(D1)

# runs focalstatistics on the original input raster
F1 = FocalStatistics(D1, neighbourhood, "SUM")

# runs focal statistics on the squared raster
F2 = FocalStatistics(D2, neighbourhood, "SUM")

# performs the TRI raster math
tri_raster = SquareRoot(F2 + (9 * D1) - (2 * D1 * F1))

# saves the final raster as the name specified by the user in teh arcGIS GUI
tri_raster.save(arcpy.GetParameterAsText(1))

# tells the user the script is complete
arcpy.AddMessage("script complete")